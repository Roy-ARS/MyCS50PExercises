myString = input("Yell something at me: ")

print(myString.lower())