strin = input()

for _ in strin:
    if _.isalnum():
        print(_, end="")
print()