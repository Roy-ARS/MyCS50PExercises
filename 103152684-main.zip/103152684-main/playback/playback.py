myStringPB = input("Tell me something: ")

print(myStringPB.replace(" ", "..."))